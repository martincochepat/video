Sonde audio de 4 s : test technique local, ni voix ni narration. Repères de fixture connus.
