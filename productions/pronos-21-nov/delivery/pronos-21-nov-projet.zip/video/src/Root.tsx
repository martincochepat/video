import {Composition} from 'remotion';
import {NovemberPredictions} from './productions/pronos-november';
export const Root=()=> <Composition id="NovemberPredictions" component={NovemberPredictions} durationInFrames={1050} fps={30} width={1080} height={1920} defaultProps={{qa:false}}/>;
