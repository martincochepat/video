import {Composition} from 'remotion';
import {FranceSpainNews} from './productions/france-spain';
export const Root=()=> <Composition id="FranceSpainNews" component={FranceSpainNews} durationInFrames={2700} fps={30} width={1080} height={1920} defaultProps={{qa:false}}/>;
