# Sources — Ligue Onze / 3 pronostics
Version technique provisoire non publiable : données sportives non vérifiées.
Node24, Chromium /usr/bin/chromium, FFmpeg/ffprobe requis.

npm ci
npm run typecheck
python productions/trois-pronostics/make-audio.py
node productions/trois-pronostics/render.mjs render

Studio : npm run studio -- --port=3000 → ThreePredictions.
Données : productions/trois-pronostics/matches.json.
Lire production-notes.md et release-status.json avant toute utilisation.
Les sources des précédentes compositions et leurs données nécessaires au bundler
sont conservées ; leurs vidéos ne sont pas recopiées dans cette archive.
