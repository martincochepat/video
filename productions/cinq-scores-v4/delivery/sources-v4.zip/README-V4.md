# V4 Ligue Onze — sources modifiables
Node24, Chromium /usr/bin/chromium et FFmpeg/ffprobe requis.

npm ci
npm run typecheck
node productions/cinq-scores-v4/render.mjs render
node productions/cinq-scores-v4/render.mjs inspect
python productions/cinq-scores-v4/examine.py

Studio : npm run studio -- --port=3000 → FiveScores.
Les assets et le mix de travail sont déjà inclus. Aucune clé ni API payante nécessaire.
La régénération vocale locale est facultative ; voir production-notes.md.
Lire matches.json, sources.json, credits.md, voiceover.txt, captions.srt et les rapports.
Les anciennes compositions sont conservées ; leurs exports vidéo sont exclus de cette archive.
Aucun média de référence tiers ni modèle vocal lourd n’est redistribué ici.
